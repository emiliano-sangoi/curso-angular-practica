/**
 * 
 */
function destacar(elem){
	console.log(elem.parentNode.nodeName);
	objPadre =elem.parentNode.parentNode; 
	if(objPadre.className=="destacado") {
		objPadre.className="";
		elem.innerHTML="Destacar";
	}
	else {
		objPadre.className= "destacado";
		elem.innerHTML="Quitar Destacado";

	}
}

function finalizar(elem){
	elem.parentNode.parentNode.style.display= "none";
}