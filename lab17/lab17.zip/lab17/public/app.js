angular.module('appConsultas', []);
// creamos el modulo de consultas 