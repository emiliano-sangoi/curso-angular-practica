var dbConn = require('./connexion');

module.exports = function(coleccion,qry,callback){
	**** hacer *****
}