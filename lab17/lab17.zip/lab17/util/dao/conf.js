module.exports = {
    "servidor": "localhost",
    "puerto": "27017",
    "db": "lab16"
}