/**
 * 
 */
function apostar(elem){
	estilos = elem.className.split(" ");
	console.log(estilos);
	if(estilos[0]=="nro") {
		elem.className="apostado "+estilos[1];
	} else 	{
		elem.className="nro "+estilos[1];
	}
}

var ruletaIntervalo;
var contador = 0;

function sortear(){
	ruletaIntervalo= setInterval(function () {myTimer()}, 500);
}

function myTimer() {
    var nro = Math.floor((Math.random() * 36));
    contador++;
    if(contador==10){
    	clearInterval(ruletaIntervalo);
    	document.getElementById("sorteo").innerHTML = "Nro Sorteado ... "+nro;
        var nrosApostados = document.querySelectorAll(".apostado");
        console.log(nrosApostados);
        for(var i=0;i<nrosApostados.length;i++){
        	console.log(nrosApostados[i].innerHTML+"=="+nro);
        	if(nrosApostados[i].innerHTML==nro) {
            	document.getElementById("resultado").innerHTML = "GANO ... !!!";
            	break;
        	}else{
        		document.getElementById("resultado").innerHTML = "La casa gana!!!!!";
        	}
        }
        contador =0;// reinicio
        return;
    }
    document.getElementById("sorteo").innerHTML = " girando..... :" + nro;
}