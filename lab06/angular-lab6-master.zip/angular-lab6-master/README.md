Laboratorio 6 del Curso Angular

Contiene el laboratorio 6 del curso "Desarrollo en AngularJS" de la UTN Santa Fe a distancia.
